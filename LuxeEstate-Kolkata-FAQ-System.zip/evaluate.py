import pandas as pd
from engine import IndiaRealEstateFAQEngine

def evaluate_bot():
    engine = IndiaRealEstateFAQEngine('/sessions/dazzling-compassionate-dijkstra/mnt/outputs/faqs.csv')

    test_cases = [
        # Domain Relevant Queries (Expected: Success) - 20 Kolkata/WB FAQs
        ("What are current home loan interest rates in Kolkata?", True),
        ("What is stamp duty in West Bengal for a male buyer?", True),
        ("How does WBHIRA protect homebuyers?", True),
        ("Property mutation process in Kolkata", True),
        ("How are property tax calculated in Kolkata KMC", True),
        ("PMAY benefits for Kolkata buyers", True),
        ("Maintenance charges for housing society in Kolkata", True),
        ("Home loan tax benefits 80C 24b", True),
        ("Builder-Buyer Agreement key clauses", True),
        ("Property registration process Kolkata", True),
        ("Khata system Kolkata", True),
        ("Freehold vs Leasehold property", True),
        ("SARFAESI bank auction process", True),
        ("Transfer of Property Act key sections", True),
        ("Home loan documents required", True),
        ("Rental agreement registration stamp duty", True),
        ("Property valuation for home loan", True),
        ("TDS on property purchase section 194IA", True),
        ("Property inheritance succession laws India", True),
        ("Legal heir certificate vs succession certificate", True),

        # Out-of-Scope Queries (Expected: Fallback)
        ("What is the weather today in Kolkata?", False),
        ("How do I bake a chocolate cake?", False),
        ("Who won the IPL final?", False),
        ("How does photosynthesis work?", False),
    ]

    results = []
    passed_count = 0

    for query, expected_success in test_cases:
        res = engine.get_answer(query)
        actual_success = (res['status'] == 'success')
        is_pass = (actual_success == expected_success)

        if is_pass:
            passed_count += 1

        results.append({
            "Query": query,
            "Expected": "Success" if expected_success else "Fallback",
            "Actual": "Success" if actual_success else "Fallback",
            "Matched Category": res['category'] if actual_success else "N/A",
            "Score": f"{res['score']:.4f}",
            "Result": "✅ Pass" if is_pass else "❌ Fail"
        })

    df_results = pd.DataFrame(results)
    output_path = '/sessions/dazzling-compassionate-dijkstra/mnt/outputs/evaluation_results.csv'
    df_results.to_csv(output_path, index=False)

    total = len(test_cases)
    accuracy = (passed_count / total) * 100

    print("=" * 80)
    print(f"BENCHMARK EVALUATION SUMMARY")
    print("=" * 80)
    print(f"Total Test Cases: {total}")
    print(f"Passed: {passed_count}")
    print(f"Failed: {total - passed_count}")
    print(f"Benchmark Accuracy: {accuracy:.1f}%")
    print(f"Results saved to: {output_path}")

if __name__ == "__main__":
    evaluate_bot()