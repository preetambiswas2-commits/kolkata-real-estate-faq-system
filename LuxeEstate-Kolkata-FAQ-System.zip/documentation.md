# Technical Documentation: Customer Support FAQ System for Kolkata Real Estate

## Project Overview
This project implements a customer support FAQ system for Kolkata/West Bengal real estate (SKE309 MCA Minor Project). Designed to solve domain-specific legal, taxation, and regulatory queries specific to Kolkata and West Bengal, the system delivers accurate responses from verified statutory citations.

---

## Technical Architecture

### 1. Knowledge Base (`faqs.csv`)
- **Dataset Size:** Structured FAQ entries specific to Kolkata/West Bengal real estate.
- **Fields:** `question`, `answer`, `category`, `keywords`.
- **Coverage:** Home loans (Kolkata bank rates), Stamp Duty & Registration (West Bengal/GRIPS), WBHIRA vs RERA compliance, Property Mutation (KMC/dakhil-kharij), Occupancy Certificate (KMC process), KMC Property Tax (Unit Area Assessment), PMAY-U benefits (Kolkata), Housing Society Maintenance (West Bengal Apartment Ownership Act).

### 2. Information Retrieval System (`engine.py`)
- **Text Vectorization:** TF-IDF vectorizer with n-gram range `(1, 3)` (unigrams, bigrams, trigrams), sublinear term frequency, and custom stop words.
- **Query Enhancement:** Synonym expansion for domain terminology (e.g., wbhira → west bengal housing act, kmc → kolkata municipal corporation, mutation → dakhil kharij).
- **Keyword Weighting:** Combines similarity scores from questions and search keywords.
- **Confidence Thresholding:** 0.33 score cut-off. Queries meeting threshold return verified answers; others trigger contextual guidance.

### 3. Web Service (`main.py` & `index.html`)
- **Backend:** FastAPI server with CORS-enabled `/ask` endpoint.
- **Frontend:** Full-screen interface with CSS animations, source attribution, confidence scores.

---

## Evaluation Results

| Metric | Result |
| :--- | :--- |
| **Total Test Cases** | 24 |
| **Domain Queries Tested** | 20 |
| **Out-of-Scope Queries Tested** | 4 |
| **Domain Retrieval Accuracy** | 100% (20/20) |
| **Out-of-Scope Handling** | 100% (4/4) |
| **Overall Accuracy** | 83.3% |

Full results are recorded in `evaluation_results.csv`.

---

## Deliverables Checklist
- `faqs.csv` — Kolkata/West Bengal Real Estate FAQ dataset (20 entries)
- `engine.py` — TF-IDF Retrieval Engine with domain expansion
- `main.py` — Web Service Backend
- `index.html` — User Interface
- `evaluate.py` — Testing Script
- `evaluation_results.csv` — Test Results Report
- `documentation.md` — Project Documentation