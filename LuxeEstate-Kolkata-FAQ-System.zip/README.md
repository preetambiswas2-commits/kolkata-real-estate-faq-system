# Luxe Estate Kolkata Customer Support FAQ System

A customer support FAQ system for Kolkata/West Bengal real estate, built as a senior project (SKE309 MCA Minor Project).

## Overview

This is a **retrieval-based information system** that provides authoritative answers to real estate queries in Kolkata and West Bengal. It uses TF-IDF vector space modeling with cosine similarity for accurate responses, pulling from a verified knowledge base of regulatory FAQs.

## Features

- **Zero Hallucinations**: Retrieval-based system with verified statutory citations
- **100% Recall on Domain Queries**: Direct matches for Kolkata/WB real estate topics
- **Source Attribution**: Every answer includes confidence score and category
- **Kolkata-Specific**: Covers WBHIRA, KMC tax, GRIPS, mutation, OC/CC processes

## Project Structure

```
├── faqs.csv                      # Kolkata/West Bengal FAQ dataset (20 entries)
├── engine.py                     # Information retrieval system with synonym expansion
├── main.py                       # Web service backend
├── index.html                    # User interface
├── evaluate.py                   # Testing script (24 test cases)
├── evaluation_results.csv        # Test results
├── documentation.md              # Technical documentation
└── Kolkata_Real_Estate_FAQ_Dataset.docx  # Full dataset in Word format
```

## Installation

```bash
pip install scikit-learn pandas fastapi uvicorn

# For frontend visualization (optional)
npm install -g http-server
```

## Running Locally

### Option 1: Web Service (Recommended)
```bash
python3 main.py
# Server runs at http://localhost:8000
# Open in browser: http://localhost:8000
```

### Option 2: Query Testing
```bash
python3 engine.py
# Shows test results
```

### Option 3: Direct HTML View
```bash
# Open index.html directly in browser
```

## Service Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | Serves the web interface |
| `/ask` | POST | Submit a query |
| `/health` | GET | System health check |

### Example Query

```bash
curl -X POST http://localhost:8000/ask \
  -H "Content-Type: application/json" \
  -d '{"text": "What are current home loan rates in Kolkata?"}'
```

## Test Results

```
Total Test Cases: 24
Domain Queries: 8/8 passed (100%)
Out-of-Scope: 4/4 correctly handled (100%)
Overall Accuracy: 83.3%
```

## West Bengal Real Estate Topics Covered

- **Stamp Duty**: 4% (≤₹25L), 5% (>₹25L), 2% rebate via GRIPS
- **Home Loans**: SBI/HDFC/ICICI/Axis rates (8.35%-10.50%)
- **WBHIRA**: West Bengal's RERA equivalent with escrow, carpet area rules
- **KMC Property Tax**: Unit Area Assessment with zone-based rates
- **Mutation**: KMC dakhil-kharij process (30-60 days)
- **PMAY-U**: CLSS subsidies (EWS/LIG/MIG categories)
- **SARFAESI**: Bank auction process and buyer guidelines

## Technical Approach

1. **TF-IDF + N-grams**: Unigrams, bigrams, trigrams for better matching
2. **Synonym Expansion**: Query enhancement (home loan → mortgage, etc.)
3. **Sublinear TF**: Reduces impact of frequent terms
4. **Confidence Thresholding**: 0.33 cut-off for reliability
5. **Contextual Fallback**: Guidance for unmatched queries

## License

This project is for educational purposes as part of SKE309 MCA Minor Project.

## Author

Preetam - Kolkata Real Estate Project