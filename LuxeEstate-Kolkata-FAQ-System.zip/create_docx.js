const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, WidthType, HeadingLevel, AlignmentType } = require("docx");
const fs = require("fs");

// Read the CSV data
const csvContent = fs.readFileSync('/sessions/dazzling-compassionate-dijkstra/mnt/outputs/faqs.csv', 'utf8');
const lines = csvContent.trim().split('\n');
const headers = lines[0].split(',').map(h => h.replace(/"/g, '').trim());
const data = lines.slice(1).map(line => {
    const fields = [];
    let current = '';
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
        const char = line[i];
        if (char === '"' && (i === 0 || line[i-1] !== '\\')) {
            inQuotes = !inQuotes;
        } else if (char === ',' && !inQuotes) {
            fields.push(current);
            current = '';
        } else {
            current += char;
        }
    }
    fields.push(current);
    return fields.map(f => f.replace(/"/g, '').trim());
});

const children = [
    new Paragraph({
        children: [
            new TextRun({
                text: "Luxe Estate Kolkata",
                bold: true,
                size: 48,
                font: "Calibri",
                color: "1F4E79"
            }),
        ],
        heading: HeadingLevel.TITLE,
        alignment: AlignmentType.CENTER,
        spacing: { after: 200 }
    }),
    new Paragraph({
        children: [
            new TextRun({
                text: "AI Concierge — Verified Knowledge Base Dataset",
                bold: false,
                size: 28,
                font: "Calibri",
                color: "2E75B6"
            }),
        ],
        heading: HeadingLevel.HEADING_1,
        alignment: AlignmentType.CENTER,
        spacing: { after: 100 }
    }),
    new Paragraph({
        children: [
            new TextRun({
                text: "Complete FAQ Dataset for Kolkata & West Bengal Real Estate",
                italic: true,
                size: 22,
                font: "Calibri",
                color: "595959"
            }),
        ],
        alignment: AlignmentType.CENTER,
        spacing: { after: 300 }
    }),
    new Paragraph({
        children: [
            new TextRun({
                text: "Project Information",
                bold: true,
                size: 24,
                font: "Calibri",
                color: "1F4E79"
            }),
        ],
        heading: HeadingLevel.HEADING_2,
        spacing: { after: 120, before: 200 }
    }),
    new Paragraph({
        children: [
            new TextRun({ text: "Course / Project: ", bold: true, size: 22 }),
            new TextRun({ text: "SKE309 MCA Minor Project — AI-Powered Customer Support FAQ Assistant", size: 22 }),
        ],
        spacing: { after: 100 }
    }),
    new Paragraph({
        children: [
            new TextRun({ text: "Domain / Market: ", bold: true, size: 22 }),
            new TextRun({ text: "Kolkata, West Bengal Real Estate", size: 22 }),
        ],
        spacing: { after: 100 }
    }),
    new Paragraph({
        children: [
            new TextRun({ text: "Total FAQs Fed: ", bold: true, size: 22 }),
            new TextRun({ text: data.length.toString(), size: 22 }),
        ],
        spacing: { after: 100 }
    }),
    new Paragraph({
        children: [
            new TextRun({ text: "Regulatory Scope: ", bold: true, size: 22 }),
            new TextRun({ text: "WBHIRA, KMC (Kolkata Municipal Corporation), WB Stamp Duty & GRIPS, PMAY-Urban, West Bengal Apartment Ownership Act", size: 22 }),
        ],
        spacing: { after: 300 }
    }),
];

// Add FAQ entries
data.forEach((row, index) => {
    const [question, answer, category, keywords] = row;
    
    children.push(
        new Paragraph({
            children: [
                new TextRun({
                    text: `FAQ ${index + 1}: ${category}`,
                    bold: true,
                    size: 24,
                    font: "Calibri",
                    color: "1F4E79"
                }),
            ],
            heading: HeadingLevel.HEADING_2,
            spacing: { before: 300, after: 100 }
        })
    );
    
    children.push(
        new Paragraph({
            children: [
                new TextRun({ text: "Question: ", bold: true, size: 22 }),
                new TextRun({ text: question, size: 22 }),
            ],
            spacing: { after: 100 }
        })
    );
    
    children.push(
        new Paragraph({
            children: [
                new TextRun({ text: "Verified Answer: ", bold: true, size: 22 }),
                new TextRun({ text: answer, size: 22 }),
            ],
            spacing: { after: 100 }
        })
    );
    
    children.push(
        new Paragraph({
            children: [
                new TextRun({ text: "Enriched Keywords: ", bold: true, size: 20, color: "595959" }),
                new TextRun({ text: keywords, size: 20, color: "595959" }),
            ],
            spacing: { after: 200 }
        })
    );
});

// Summary Table
const tableRows = [
    new TableRow({
        children: [
            new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "#", bold: true, size: 20 })] })], width: { size: 600, type: WidthType.DXA } }),
            new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Category", bold: true, size: 20 })] })], width: { size: 2800, type: WidthType.DXA } }),
            new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Question", bold: true, size: 20 })] })], width: { size: 6000, type: WidthType.DXA } }),
            new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: "Keywords", bold: true, size: 20 })] })], width: { size: 4600, type: WidthType.DXA } }),
        ],
        tableHeader: true
    })
];

data.forEach((row, index) => {
    const [question, answer, category, keywords] = row;
    tableRows.push(
        new TableRow({
            children: [
                new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: (index + 1).toString(), size: 18 })] })], width: { size: 600, type: WidthType.DXA } }),
                new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: category, size: 18 })] })], width: { size: 2800, type: WidthType.DXA } }),
                new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: question, size: 18 })] })], width: { size: 6000, type: WidthType.DXA } }),
                new TableCell({ children: [new Paragraph({ children: [new TextRun({ text: keywords, size: 18 })] })], width: { size: 4600, type: WidthType.DXA } }),
            ]
        })
    );
});

children.push(
    new Paragraph({
        children: [
            new TextRun({
                text: "Complete Dataset Reference Table",
                bold: true,
                size: 24,
                font: "Calibri",
                color: "1F4E79"
            }),
        ],
        heading: HeadingLevel.HEADING_2,
        spacing: { before: 400, after: 200 }
    })
);

children.push(
    new Table({
        width: { size: 14000, type: WidthType.DXA },
        columnWidths: [600, 2800, 6000, 4600],
        rows: tableRows,
    })
);

const doc = new Document({
    sections: [{
        properties: {},
        children: children
    }]
});

Packer.toBuffer(doc).then(buffer => {
    fs.writeFileSync('/sessions/dazzling-compassionate-dijkstra/mnt/outputs/Kolkata_Real_Estate_FAQ_Dataset.docx', buffer);
    console.log("DOCX created successfully at /sessions/dazzling-compassionate-dijkstra/mnt/outputs/Kolkata_Real_Estate_FAQ_Dataset.docx");
});
