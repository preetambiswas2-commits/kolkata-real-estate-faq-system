import streamlit as st
import pandas as pd
from engine import FAQBotEngine

# Page Configuration
st.set_page_config(page_title="SaaS Support Assistant", page_icon="🤖")

# Initialize the Engine (Cached to avoid reloading CSV every time)
@st.cache_resource
def load_engine():
    return FAQBotEngine('/sessions/dazzling-compassionate-dijkstra/mnt/outputs/faqs.csv')

engine = load_engine()

# UI Layout
st.title("🤖 SaaS Customer Support Assistant")
st.markdown("""
Welcome to our AI-powered FAQ assistant. I can help you with account management, billing, security, and technical questions.
""")

# Session State for Chat History
if "messages" not in st.session_state:
    st.session_state.messages = []

# Display Chat History
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])
        if "details" in message:
            with st.expander("View Retrieval Details"):
                st.write(message["details"])

# User Input
if prompt := st.chat_input("How can I help you today?"):
    # Add user message to chat history
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    # Get response from engine
    with st.chat_message("assistant"):
        result = engine.get_answer(prompt)
        response = result["answer"]
        st.markdown(response)

        # Details for verification (as required by project objectives)
        details = f"""
        **Matched Question:** {result['matched_question']}
        **Confidence Score:** {result['score']:.4f}
        **Category:** {result['category']}
        **Status:** {result['status']}
        """
        if result['status'] == 'fallback':
            details = f"**Confidence Score:** {result['score']:.4f} (Below threshold)"

        with st.expander("View Retrieval Details"):
            st.write(details)

    # Add assistant response to history
    st.session_state.messages.append({
        "role": "assistant",
        "content": response,
        "details": details
    })
