from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel
from engine import IndiaRealEstateFAQEngine
import uvicorn
from fastapi.middleware.cors import CORSMiddleware
import os

app = FastAPI(title="Luxe Estate Kolkata Concierge API", version="3.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
csv_path = os.path.join(BASE_DIR, "faqs.csv")

try:
    engine = IndiaRealEstateFAQEngine(csv_path)
    print(f"✓ India FAQ Engine initialized with {len(engine.df)} entries")
except Exception as e:
    print(f"✗ Error loading FAQ engine: {e}")
    engine = None

class QueryRequest(BaseModel):
    text: str

@app.get("/")
async def serve_frontend():
    index_path = os.path.join(BASE_DIR, "index.html")
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return {"message": "Luxe Estate India FAQ API is running. Frontend not found."}

@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "engine": "initialized" if engine else "failed",
        "faq_count": len(engine.df) if engine else 0,
        "region": "India"
    }

@app.post("/ask")
async def ask_faq(request: QueryRequest):
    if not engine:
        raise HTTPException(status_code=500, detail="FAQ engine not initialized.")
    try:
        result = engine.get_answer(request.text)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    print("╔═══════════════════════════════════════════════╗")
    print("║     LUXE ESTATE INDIA AI CONCIERGE           ║")
    print("║     Starting on http://localhost:8000        ║")
    print("╚═══════════════════════════════════════════════╝")
    uvicorn.run(app, host="0.0.0.0", port=8000)