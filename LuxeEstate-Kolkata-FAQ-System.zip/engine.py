import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
import os
import re

class IndiaRealEstateFAQEngine:
    def __init__(self, csv_path):
        if not os.path.exists(csv_path):
            raise FileNotFoundError(f"Dataset not found at {csv_path}")

        self.df = pd.read_csv(csv_path, quotechar='"', skipinitialspace=True)
        self.df['question'] = self.df['question'].str.strip()

        # Create combined text for better matching (question + keywords)
        if 'keywords' in self.df.columns:
            self.df['search_text'] = self.df['question'] + ' ' + self.df['keywords'].fillna('')
        else:
            self.df['search_text'] = self.df['question']

        # Enhanced vectorizer with n-grams, sublinear tf, and custom stop words
        indian_stop_words = {
            'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by',
            'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did',
            'will', 'would', 'could', 'should', 'may', 'might', 'must', 'can', 'what', 'how', 'when',
            'where', 'why', 'who', 'which', 'this', 'that', 'these', 'those', 'my', 'your', 'his', 'her',
            'its', 'our', 'their', 'i', 'you', 'he', 'she', 'it', 'we', 'they', 'me', 'him', 'us', 'them'
        }

        self.vectorizer = TfidfVectorizer(
            stop_words=list(indian_stop_words),
            ngram_range=(1, 3),  # unigrams, bigrams, trigrams
            sublinear_tf=True,
            min_df=1,
            max_df=0.95,
            max_features=5000
        )
        self.tfidf_matrix = self.vectorizer.fit_transform(self.df['search_text'])

        # Pre-compute question vectors for fast matching
        self.question_vectors = self.vectorizer.transform(self.df['question'])

    def _preprocess_query(self, query):
        """Enhance query with common Indian real estate synonyms"""
        synonyms = {
            'home loan': 'housing loan mortgage',
            'housing loan': 'home loan mortgage',
            'stamp duty': 'stampduty registration charges',
            'registration': 'registry registrar',
            'rera': 'real estate regulatory authority',
            'carpet area': 'carpetarea usable area',
            'built up': 'builtup',
            'super built up': 'superbuiltup super builtup',
            'capital gains': 'capitalgains cgt ltcg stcg',
            'section 80c': '80c',
            'section 24b': '24b 24(b)',
            'section 54': '54',
            'section 54ec': '54ec',
            'nri': 'non resident indian overseas citizen',
            'oci': 'overseas citizen of india',
            'gst': 'goods services tax',
            'tds': 'tax deducted source',
            'mutation': 'dakhil kharij',
            'occupancy certificate': 'oc completion certificate cc',
            'completion certificate': 'cc occupancy certificate oc',
            'sarfaesi': 'auction bank auction',
            'pmay': 'pradhan mantri awas yojana clss subsidy',
            'mhada': 'maharashtra housing area development authority lottery',
            'kmc': 'kolkata municipal corporation',
            'wbhira': 'west bengal housing industry regulation act protect homebuyers',
            'nocs': 'no objection certificate',
            'power of attorney': 'poa',
            'gift deed': 'giftdeed',
            'benami': 'benami transaction',
            'rera complaint': 'rera grievance',
            'balance transfer': 'bt home loan transfer',
            'prepayment': 'foreclosure part payment',
            'eblr': 'external benchmark lending rate repo rate',
            'cii': 'cost inflation index',
            'form 15ca': '15ca 15cb',
            'form 26qb': '26qb',
            'form 26qc': '26qc',
            'form 16b': '16b',
            'khata': 'khatha certificate extract',
            '7/12': '7/12 extract satbara',
            'rtc': 'record of rights tenancy crops',
            'circle rate': 'guidance value ready reckoner',
            'ready reckoner': 'circle rate guidance value',
        }

        query_lower = query.lower()
        for term, expansion in synonyms.items():
            if term in query_lower:
                query_lower += ' ' + expansion
        return query_lower

    def get_answer(self, user_query, threshold=0.42):
        if not user_query or not user_query.strip():
            return {
                "answer": "Please ask a specific question about Indian real estate — home loans, RERA, stamp duty, capital gains, NRI investments, property registration, or tax planning.",
                "matched_question": None,
                "score": 0.0,
                "category": None,
                "status": "empty"
            }

        # Preprocess query with synonyms
        enhanced_query = self._preprocess_query(user_query)

        # Vectorize both original and enhanced query
        query_vec = self.vectorizer.transform([user_query])
        enhanced_vec = self.vectorizer.transform([enhanced_query])

        # Compute similarities
        similarities = cosine_similarity(query_vec, self.tfidf_matrix).flatten()
        enhanced_similarities = cosine_similarity(enhanced_vec, self.tfidf_matrix).flatten()

        # Combine scores (weighted)
        combined_scores = 0.4 * similarities + 0.6 * enhanced_similarities

        best_idx = np.argmax(combined_scores)
        best_score = float(combined_scores[best_idx])

        # Also check direct question similarity for exact matches
        q_similarities = cosine_similarity(query_vec, self.question_vectors).flatten()
        q_best_idx = np.argmax(q_similarities)
        q_best_score = float(q_similarities[q_best_idx])

        # Use the better of the two approaches
        if q_best_score > best_score:
            best_idx = q_best_idx
            best_score = q_best_score

        if best_score >= 0.33:
            answer = self.df.iloc[best_idx]['answer']
            matched_q = self.df.iloc[best_idx]['question']
            category = self.df.iloc[best_idx]['category']

            # Enhance answer with source attribution
            enhanced_answer = f"{answer}\n\n— Source: {category} | Confidence: {best_score:.0%}"

            return {
                "answer": enhanced_answer,
                "matched_question": matched_q,
                "score": round(best_score, 4),
                "category": category,
                "status": "success"
            }
        else:
            # Try to give a helpful fallback based on category detection
            fallback_answer = self._generate_contextual_fallback(user_query, best_score)
            return {
                "answer": fallback_answer,
                "matched_question": None,
                "score": round(best_score, 4),
                "category": None,
                "status": "fallback"
            }

    def _generate_contextual_fallback(self, query, score):
        query_lower = query.lower()

        # Detect likely category from keywords
        categories = {
            'home loan': ['home loan', 'housing loan', 'mortgage', 'interest rate', 'emi', 'prepayment', 'foreclosure', 'balance transfer', 'eblr', 'repo rate'],
            'stamp duty': ['stamp duty', 'registration', 'registry', 'stampduty'],
            'rera': ['rera', 'carpet area', 'builder', 'delay', 'possession', 'escrow'],
            'tax': ['tax', 'capital gains', 'section 80c', 'section 24', 'section 54', 'section 54ec', 'income tax', 'tds', 'gst', 'new regime', 'old regime'],
            'nri': ['nri', 'oci', 'non resident', 'overseas citizen', 'repatriation', 'fema', '15ca', '15cb'],
            'property docs': ['mutation', 'dakhil kharij', 'khata', 'khatha', '7/12', 'rtc', 'encumbrance', 'title deed', 'oc', 'cc', 'occupancy', 'completion'],
            'society': ['society', 'maintenance', 'sinking fund', 'managing committee', 'bye-laws', 'mcs act'],
            'inheritance': ['inheritance', 'succession', 'will', 'probate', 'legal heir', 'gift deed', 'partition'],
            'auction': ['sarfaesi', 'auction', 'bank auction', 'reserve price', 'emd'],
            'pmay': ['pmay', 'clss', 'subsidy', 'ews', 'lig', 'mig'],
            'land': ['agricultural', 'na conversion', 'non-agricultural', 'collector', 'town planning'],
            'rental': ['rent', 'tenant', 'landlord', 'lease', 'leave license', '194ib'],
            'valuation': ['valuation', 'circle rate', 'guidance value', 'ready reckoner', 'reinstatement'],
            'rei': ['reit', 'real estate investment trust', 'embassy', 'mindspace', 'brookfield', 'nexus'],
        }

        detected = None
        for cat, keywords in categories.items():
            if any(kw in query_lower for kw in keywords):
                detected = cat
                break

        contextual_advice = {
            'home loan': "For home loan queries, please specify: bank name, loan amount, salaried/self-employed, or ask about current rates from major lenders (SBI, HDFC, ICICI, Kotak, Axis).",
            'stamp duty': "Stamp duty varies by state and gender. Please specify the state (Maharashtra, Delhi, Karnataka, etc.) and buyer gender for accurate rates.",
            'rera': "For RERA queries, mention the state (MahaRERA, UP-RERA, Karnataka RERA) or ask about specific protections: carpet area, delay compensation, escrow, or complaint filing.",
            'tax': "Tax queries need specifics: property value, holding period, residential/commercial, self-occupied/let-out, or section number (80C, 24(b), 54, 54EC).",
            'nri': "NRI/OCI rules depend on account type (NRE/NRO/FCNR), property type, and country of residence. Specify for precise guidance.",
            'property docs': "Document processes vary by state. Mention the state (Maharashtra Bhulekh, Karnataka Bhoomi, Delhi DORIS) for portal-specific steps.",
            'society': "Society charges governed by state acts (MCS Act in Maharashtra). Share your state for accurate sinking fund, repair fund, and bye-law details.",
            'inheritance': "Succession laws differ by religion (Hindu, Muslim, Christian, Parsi). Specify religion and whether Will exists for accurate guidance.",
            'auction': "SARFAESI auctions are 'as is where is'. Due diligence on title, occupants, and dues is critical. No home loan usually available.",
            'pmay': "PMAY-CLSS eligibility: income category, first pucca house, female co-owner (EWS/LIG), Aadhaar. Check with your bank (PLI).",
            'land': "NA conversion requires Collector permission under state revenue codes. Share state for specific section (Maharashtra Sec 44, Karnataka Sec 95).",
            'rental': "Rental laws: Agreement >11 months needs registration. TDS @5% if rent >₹50k/month (194IB). NRI landlord: 31.2% (195).",
            'valuation': "Valuation methods: Market comparison (home loan), Reinstatement value (insurance), Circle rate/Ready Reckoner (stamp duty).",
            'rei': "Listed REITs: Embassy, Mindspace, Brookfield, Nexus Select. Taxation varies by distribution component (interest/dividend/rental/capital repayment).",
        }

        advice = contextual_advice.get(detected, "For specialized queries — structuring NRI investments, complex capital gains planning, RERA disputes, or SARFAESI auctions — consult a RERA-registered property lawyer or chartered accountant for tailored guidance.")

        return f"I don't have a precise match in my verified knowledge base for this query (confidence: {score:.0%}).\n\n{advice}\n\nYou can try rephrasing with specific details (state, property type, value, section number) or ask one of the suggested questions below."

if __name__ == "__main__":
    engine = IndiaRealEstateFAQEngine('/sessions/dazzling-compassionate-dijkstra/mnt/outputs/faqs.csv')
    print(f"Loaded {len(engine.df)} Kolkata-specific FAQs")
    print()

    test_queries = [
        # Domain Relevant Queries (Expected: Success)
        "What are current home loan interest rates in Kolkata?",
        "What is stamp duty in West Bengal for a male buyer?",
        "How does WBHIRA protect homebuyers?",
        "Property mutation process in Kolkata",
        "OC process in Kolkata KMC",
        "How are property tax calculated in Kolkata KMC",
        "PMAY benefits for Kolkata buyers",
        "Maintenance charges for housing society in Kolkata",

        # Out-of-Scope Queries (Expected: Fallback)
        "What is the weather today in Kolkata?",
        "How do I bake a chocolate cake?",
        "Who won the IPL final?",
        "How does photosynthesis work?",
    ]

    print("=" * 80)
    print("ACCURACY TEST RESULTS")
    print("=" * 80)

    success = 0
    fallback = 0
    for q in test_queries:
        r = engine.get_answer(q)
        status_icon = "✓" if r['status'] == 'success' else "✗"
        if r['status'] == 'success':
            success += 1
        else:
            fallback += 1
        print(f"{status_icon} [{r['score']:.2f}] {q[:60]}...")
        if r['status'] == 'success':
            print(f"    → {r['category']} | {r['matched_question'][:70]}...")
        else:
            print(f"    → FALLBACK: {r['answer'][:100]}...")
        print()

    print(f"Total: {len(test_queries)} | Success: {success} | Fallback: {fallback} | Accuracy: {success/len(test_queries)*100:.1f}%")